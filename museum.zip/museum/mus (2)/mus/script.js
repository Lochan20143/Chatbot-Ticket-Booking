
document.addEventListener('DOMContentLoaded', function () {
    console.log('Document loaded');
});