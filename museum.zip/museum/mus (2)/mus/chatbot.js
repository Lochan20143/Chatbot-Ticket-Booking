document.addEventListener("DOMContentLoaded", function() {
    const chatContainer = document.getElementById('chat-container');
    const userInput = document.getElementById('user-input');

    // Initial variables
    let step = 0;
    let bookingDetails = {
        museum: '',
        date: '',
        time: '',
        tickets: 0
    };
    const museums = [
        { name: "National Gallery of Modern Art", price: 250 },
        { name: "Visvesvaraya Industrial and Technological Museum", price: 150 },
        { name: "Karnataka Chitrakala Parishath", price: 180 },
        { name: "Government Museum", price: 120 },
        { name: "HAL Aerospace Museum", price: 150 },
        { name: "NIMHANS Brain Museum", price: 180 }
    ];

    let selectedMuseum = null;

    // Load saved progress
    window.onload = function() {
        const savedStep = localStorage.getItem('chatbotStep');
        if (savedStep) {
            step = parseInt(savedStep, 10);
            bookingDetails = JSON.parse(localStorage.getItem('bookingDetails') || '{}');
        }
    };

    // Save progress
    function saveProgress() {
        localStorage.setItem('chatbotStep', step);
        localStorage.setItem('bookingDetails', JSON.stringify(bookingDetails));
    }

    // Reset chatbot
    window.resetChatbot = function() {
        step = 0;
        bookingDetails = { museum: '', date: '', time: '', tickets: 0 };
        localStorage.clear();
        appendMessage('bot', "The session has been reset. Type 'hello' to start again.");
    };

    // Add an event listener to handle "Enter" key press on the input field
    userInput.addEventListener("keypress", function(event) {
        if (event.key === "Enter") {
            sendMessage();
        }
    });

    // Function to display museum list
    function displayMuseums() {
        let museumTable = `<div class="overflow-x-auto"><table class="table-auto w-full text-left">
            <thead><tr><th>Museum</th><th>Entry Price (₹)</th></tr></thead><tbody>`;
        
        museums.forEach(museum => {
            museumTable += `<tr><td>${museum.name}</td><td>${museum.price}</td></tr>`;
        });

        museumTable += `</tbody></table></div>`;
        return museumTable;
    }

    // Display museum options as buttons
    function displayMuseumOptions() {
        let buttons = museums.map(museum => {
            return `<button onclick="sendMessage('${museum.name}')" class="bg-blue-500 text-white p-2 rounded m-1">${museum.name}</button>`;
        }).join("");
        return `<div>${buttons}</div>`;
    }

    // Bot responses
    function getBotResponse(userMessage) {
        if (userMessage.toLowerCase() === "hello") {
            step = 0; // Reset step to initial
            return `Hello! Here are the available museums and their entry prices:` + displayMuseums() + 
                   `<br>Select the museum you'd like to book tickets for:` + displayMuseumOptions();
        }

        switch(step) {
            case 0:
                selectedMuseum = museums.find(museum => museum.name.toLowerCase() === userMessage.toLowerCase());
                if (selectedMuseum) {
                    bookingDetails.museum = selectedMuseum.name;
                    step++;
                    saveProgress();
                    return `Great choice! You have selected ${selectedMuseum.name}. The entry price is ₹ ${selectedMuseum.price}. Please select the date you'd like to visit using the calendar below:<br>` + generateDateInput();
                } else {
                    return "Please enter a valid museum name from the list.";
                }
            case 1:
                bookingDetails.date = userMessage;
                step++;
                saveProgress();
                return `You want to visit on ${bookingDetails.date}. Please select a time from the options below: <br>` + generateTimeSlots();
            case 2:
                bookingDetails.time = userMessage; // Capture the selected time
                step++;
                saveProgress();  // Ensure step is incremented and saved
                return `You've chosen to visit at ${bookingDetails.time} on ${bookingDetails.date}. How many tickets would you like to book? Please select from the options below (1-5 tickets) or choose "Custom" for more than 5 tickets: <br>` + generateTicketOptions();
            case 3:
                if (userMessage <= 5) {  // Handling predefined options for 1-5 tickets
                    bookingDetails.tickets = parseInt(userMessage);
                    step++;
                    saveProgress();
                    const totalCost = calculateTotalCost(bookingDetails.tickets, selectedMuseum.price);
                    return `Booking confirmed for ${bookingDetails.tickets} ticket(s) to ${bookingDetails.museum} on ${bookingDetails.date} at ${bookingDetails.time}. The total cost is ₹${totalCost}. Would you like to proceed with payment? Type 'yes' to proceed or 'no' to cancel.`;
                } else if (userMessage === "custom") {  // Handling custom option
                    return generateCustomTicketInput();
                } else {
                    return "Please select a valid option or type 'custom' for more than 5 tickets.";
                }
            case 4:
                if (validateTickets(userMessage)) {
                    bookingDetails.tickets = parseInt(userMessage);
                    step++;
                    saveProgress();
                    const totalCost = calculateTotalCost(bookingDetails.tickets, selectedMuseum.price);
                    return `Booking confirmed for ${bookingDetails.tickets} ticket(s) to ${bookingDetails.museum} on ${bookingDetails.date} at ${bookingDetails.time}. The total cost is ₹${totalCost}. Would you like to proceed with payment? Type 'yes' to proceed or 'no' to cancel.`;
                } else {
                    return "Please enter a valid number of tickets.";
                }
            case 5:
                if (userMessage.toLowerCase() === 'yes') {
                    initiatePayment();
                    return `Redirecting to payment...`;
                } else if (userMessage.toLowerCase() === 'no') {
                    step = 0; // Reset for new booking
                    saveProgress();
                    return "Booking cancelled. If you'd like to book another museum ticket, please start over.";
                } else {
                    return "Please type 'yes' to proceed with payment or 'no' to cancel.";
                }
            default:
                return "Thank you! If you have any other questions or need further assistance, please let me know!";
        }
    }

    // Function to generate a date input field with the current date as the minimum
    function generateDateInput() {
        const today = new Date().toISOString().split('T')[0];  // Get current date in YYYY-MM-DD format
        return `<input id="date-input" type="date" min="${today}" onchange="sendDate()" class="border rounded p-2 mt-2" />`;
    }

    // Function to handle date selection
    window.sendDate = function() {
        const dateInput = document.getElementById('date-input');
        const selectedDate = dateInput.value;
        if (selectedDate) {
            appendMessage('user', selectedDate);
            const botMessage = getBotResponse(selectedDate);
            appendMessage('bot', botMessage);
        }
    }

    // Function to generate time slots for selection
    function generateTimeSlots() {
        const timeSlots = ["10:00 AM", "12:00 PM", "2:30 PM", "4:00 PM", "6:00 PM"];
        let buttons = timeSlots.map(time => {
            return `<button onclick="sendTime('${time}')" class="bg-blue-500 text-white p-2 rounded m-1">${time}</button>`;
        }).join("");

        return `<div>${buttons}<br><button onclick="customTime()" class="bg-yellow-500 text-white p-2 rounded m-1">Custom Time</button></div>`;
    }

    // Function to handle time selection from predefined slots
    window.sendTime = function(time) {
        appendMessage('user', time);
        const botMessage = getBotResponse(time); // Ensure step is incremented here
        appendMessage('bot', botMessage);
    }

    // Function to generate ticket options (1-5 tickets or custom input)
    function generateTicketOptions() {
        const ticketOptions = [1, 2, 3, 4, 5];  // Predefined ticket options
        let buttons = ticketOptions.map(ticket => {
            return `<button onclick="sendTickets(${ticket})" class="bg-blue-500 text-white p-2 rounded m-1">${ticket}</button>`;
        }).join("");

        return `<div>${buttons}<br><button onclick="customTickets()" class="bg-yellow-500 text-white p-2 rounded m-1">Custom</button></div>`;
    }

    // Function to handle ticket selection from predefined options
    window.sendTickets = function(ticketCount) {
        appendMessage('user', ticketCount + " ticket(s)");
        const botMessage = getBotResponse(ticketCount);
        appendMessage('bot', botMessage);
    }

    // Function to generate custom ticket input
    function generateCustomTicketInput() {
        return `<input id="custom-ticket-input" type="number" min="6" placeholder="Enter number of tickets" class="border rounded p-2 mt-2" /> 
                <button onclick="sendCustomTickets()" class="bg-green-500 text-white p-2 rounded m-1">Submit</button>`;
    }

    // Function for custom ticket entry
    window.customTickets = function() {
        const customTicketInput = generateCustomTicketInput();
        appendMessage('bot', customTicketInput);
    }

    // Function to handle custom ticket input
    window.sendCustomTickets = function() {
        const customTickets = document.getElementById('custom-ticket-input').value.trim();
        if (validateTickets(customTickets)) {
            appendMessage('user', customTickets + " ticket(s)");
            const botMessage = getBotResponse(customTickets);
            appendMessage('bot', botMessage);
        } else {
            appendMessage('bot', "Please enter a valid number of tickets (minimum 6).");
        }
    }

    // Function to validate time format (simple HH:MM AM/PM format check)
    function validateTime(time) {
        const regex = /^(0?[1-9]|1[0-2]):[0-5][0-9]\s?(AM|PM)$/i;
        return regex.test(time);
    }

    // Function to validate number of tickets
    function validateTickets(tickets) {
        const num = parseInt(tickets);
        return num > 0 && Number.isInteger(num);
    }

    // Function to calculate total cost based on number of tickets
    function calculateTotalCost(tickets, pricePerTicket) {
        return tickets * pricePerTicket;
    }

    // Function to initiate payment using Razorpay
    function initiatePayment() {
        const totalCost = calculateTotalCost(bookingDetails.tickets, selectedMuseum.price);
        
        const options = {
            key: "YOUR_RAZORPAY_KEY_ID", // Replace with your Razorpay Key ID
            amount: totalCost * 100, // Amount is in currency subunits. Default currency is INR. Hence, 100 means 100 paise or 1 INR.
            currency: "INR",
            name: "Museum Ticket Booking",
            description: `Booking for ${bookingDetails.museum}`,
            image: "https://your-site.com/logo.png", // Replace with your site logo URL
            handler: function (response) {
                alert('Payment successful! Payment ID: ' + response.razorpay_payment_id);
                step = 0; // Reset the chatbot after successful payment
                saveProgress();
                generateTicketPDF(); // Generate the ticket PDF after payment
                appendMessage('bot', 'Thank you for your purchase! Your booking is confirmed.');
            },
            prefill: {
                email: "user@example.com", // Replace with the customer's email
                contact: "9999999999" // Replace with the customer's phone number
            },
            theme: {
                color: "#3399cc"
            }
        };

        const rzp = new Razorpay(options);
        rzp.open();
    }

    // Function to generate ticket PDF using jsPDF
    function generateTicketPDF() {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();

        const ticketContent = `
        Museum: ${bookingDetails.museum}
        Date: ${bookingDetails.date}
        Time: ${bookingDetails.time}
        Number of Tickets: ${bookingDetails.tickets}
        `;

        // Add ticket content to the PDF
        doc.text("Museum Ticket", 10, 10);
        doc.text(ticketContent, 10, 20);

        // Save the generated PDF
        doc.save(`Museum_Ticket_${bookingDetails.museum}_${bookingDetails.date}.pdf`);
    }

    // Function to append typing indicator
    function appendTypingIndicator() {
        const typingElement = document.createElement('div');
        typingElement.id = 'typing-indicator';
        typingElement.className = 'text-left';
        typingElement.innerHTML = `<div class="inline-block bg-gray-200 p-2 m-1 rounded-lg">The bot is typing...</div>`;
        chatContainer.appendChild(typingElement);
        chatContainer.scrollTop = chatContainer.scrollHeight;
    }

    // Function to remove typing indicator
    function removeTypingIndicator() {
        const typingElement = document.getElementById('typing-indicator');
        if (typingElement) {
            typingElement.remove();
        }
    }

    // Function to append message to chat
    function appendMessage(sender, message) {
        const messageElement = document.createElement('div');
        messageElement.className = sender === 'user' ? 'text-right' : 'text-left';
        messageElement.innerHTML = `<div class="inline-block bg-${sender === 'user' ? 'blue' : 'gray'}-200 p-2 m-1 rounded-lg">${message}</div>`;
        chatContainer.appendChild(messageElement);
        chatContainer.scrollTop = chatContainer.scrollHeight;
    }

    // Send message function
    window.sendMessage = function(userMessageOverride = null) {
        const userMessage = userMessageOverride || userInput.value.trim();
        if (userMessage === "") return;

        appendMessage('user', userMessage);
        userInput.value = '';

        appendTypingIndicator();

        setTimeout(() => {
            removeTypingIndicator();
            const botMessage = getBotResponse(userMessage);
            appendMessage('bot', botMessage);
        }, 1000);
    };
});
